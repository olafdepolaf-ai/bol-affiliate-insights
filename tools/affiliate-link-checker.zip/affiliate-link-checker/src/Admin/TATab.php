<?php

namespace TuinenBalkon\AffiliateLinkChecker\Admin;

use TuinenBalkon\AffiliateLinkChecker\Service\ThirstyAffiliatesService;

class TATab {

	private ThirstyAffiliatesService $ta_service;

	public function __construct( ThirstyAffiliatesService $ta_service ) {
		$this->ta_service = $ta_service;
	}

	public function render(): void {
		$subtabs = [
			'rapport' => 'Rapport',
		];

		$current_subtab = isset( $_GET['subtab'] ) ? sanitize_key( $_GET['subtab'] ) : 'rapport';
		if ( ! array_key_exists( $current_subtab, $subtabs ) ) {
			$current_subtab = 'rapport';
		}

		$page_url = admin_url( 'admin.php?page=affiliate-link-checker&tab=ta' );
		?>
		<style>
			.alc-subtab-nav { display:flex; gap:0; border-bottom:1px solid #ccd0d4; margin-bottom:20px; }
			.alc-subtab-link { padding:8px 16px; text-decoration:none; color:#3c434a; border:1px solid transparent;
				border-bottom:none; border-radius:4px 4px 0 0; font-size:13px; }
			.alc-subtab-link:hover { color:#2271b1; background:#f0f0f1; }
			.alc-subtab-active { background:#fff; border-color:#ccd0d4; color:#1d2327; font-weight:600;
				margin-bottom:-1px; padding-bottom:9px; }

			.alc-ta-table { border-collapse:collapse; width:100%; margin-top:4px; }
			.alc-ta-table th, .alc-ta-table td { padding:8px 12px; border:1px solid #e0e0e0; font-size:13px;
				text-align:left; vertical-align:middle; }
			.alc-ta-table th { background:#f6f7f7; font-weight:600; }
			.alc-ta-table tr:nth-child(even) { background:#fafafa; }
			.alc-ta-table td.alc-clicks-cell { text-align:right; font-variant-numeric:tabular-nums; }
			.alc-ta-table td.alc-rank-cell { text-align:center; color:#646970; width:40px; }
			.alc-ta-zero { color:#b0b0b0; }

			.alc-ta-bar-wrap { display:inline-block; background:#e8edf0; border-radius:3px;
				height:10px; width:80px; vertical-align:middle; margin-left:8px; overflow:hidden; }
			.alc-ta-bar { background:#2271b1; height:100%; border-radius:3px; }

			.alc-ta-pagination { display:flex; align-items:center; gap:6px; margin-top:14px; flex-wrap:wrap; }
			.alc-ta-pagination a, .alc-ta-pagination span { padding:5px 10px; border:1px solid #ccd0d4;
				border-radius:3px; font-size:13px; text-decoration:none; color:#2271b1; background:#fff; }
			.alc-ta-pagination .current-page { background:#2271b1; color:#fff; border-color:#2271b1; font-weight:700; }
			.alc-ta-pagination .dots { border:none; background:none; color:#646970; padding:5px 4px; }

			.alc-ta-summary { font-size:13px; color:#646970; margin-bottom:12px; }

			.alc-ta-no-table { background:#fff8e5; border-left:4px solid #f0b849; padding:12px 16px;
				font-size:13px; border-radius:0 4px 4px 0; margin-top:8px; }
		</style>

		<nav class="alc-subtab-nav">
			<?php foreach ( $subtabs as $slug => $label ) : ?>
			<a href="<?php echo esc_url( $page_url . '&subtab=' . $slug ); ?>"
			   class="alc-subtab-link <?php echo $current_subtab === $slug ? 'alc-subtab-active' : ''; ?>">
				<?php echo esc_html( $label ); ?>
			</a>
			<?php endforeach; ?>
		</nav>

		<?php
		if ( $current_subtab === 'rapport' ) {
			$this->render_rapport_subtab();
		}
	}

	private function render_rapport_subtab(): void {
		$current_year  = (int) gmdate( 'Y' );
		$selected_year = isset( $_GET['ta_year'] ) ? (int) $_GET['ta_year'] : $current_year;
		$per_page      = 50;
		$current_page  = isset( $_GET['tapaged'] ) ? max( 1, (int) $_GET['tapaged'] ) : 1;

		$page_url = admin_url( 'admin.php?page=affiliate-link-checker&tab=ta&subtab=rapport' );

		$data        = $this->ta_service->get_clicks_by_year( $selected_year, $current_page, $per_page );
		$total_links = $data['total'];
		$total_pages = $per_page > 0 ? (int) ceil( $total_links / $per_page ) : 1;
		$offset      = ( $current_page - 1 ) * $per_page;

		$total_clicks_year = $this->ta_service->get_total_clicks_for_year( $selected_year );

		$max_clicks = 0;
		if ( ! empty( $data['items'] ) ) {
			$max_clicks = (int) $data['items'][0]->click_count;
		}
		?>
		<div style="display:flex; align-items:center; gap:12px; margin-bottom:20px; flex-wrap:wrap;">
			<form method="get" style="display:flex; align-items:center; gap:8px;">
				<input type="hidden" name="page" value="affiliate-link-checker">
				<input type="hidden" name="tab" value="ta">
				<input type="hidden" name="subtab" value="rapport">
				<label for="ta-year-select" style="font-size:13px; font-weight:600;">Jaar:</label>
				<select id="ta-year-select" name="ta_year" style="font-size:13px;">
					<?php for ( $y = $current_year; $y >= $current_year - 5; $y-- ) : ?>
					<option value="<?php echo esc_attr( $y ); ?>" <?php selected( $selected_year, $y ); ?>>
						<?php echo esc_html( $y ); ?>
					</option>
					<?php endfor; ?>
				</select>
				<button type="submit" class="button">Toon</button>
			</form>
		</div>

		<?php if ( $data['table_missing'] ) : ?>
		<div class="alc-ta-no-table">
			<strong>Click tracking tabel niet gevonden.</strong><br>
			ThirstyAffiliates Pro is vereist voor klikregistratie.
			Zorg dat de Pro-module actief is en dat de tabel
			<code><?php echo esc_html( $GLOBALS['wpdb']->prefix . 'ta_click_logs' ); ?></code> bestaat.
		</div>
		<?php return; endif; ?>

		<div class="alc-ta-summary">
			<strong><?php echo esc_html( number_format_i18n( $total_clicks_year ) ); ?></strong> kliks in <?php echo esc_html( $selected_year ); ?>
			&nbsp;·&nbsp;
			<?php echo esc_html( number_format_i18n( $total_links ) ); ?> links
			&nbsp;·&nbsp;
			Pagina <?php echo esc_html( $current_page ); ?> van <?php echo esc_html( max( 1, $total_pages ) ); ?>
		</div>

		<?php if ( empty( $data['items'] ) ) : ?>
		<p style="color:#646970; font-size:13px;">Geen klikdata gevonden voor <?php echo esc_html( $selected_year ); ?>.</p>
		<?php else : ?>
		<table class="alc-ta-table">
			<thead>
				<tr>
					<th class="alc-rank-cell">#</th>
					<th>Link naam</th>
					<th>Destination URL</th>
					<th style="text-align:right; white-space:nowrap;">Kliks <?php echo esc_html( $selected_year ); ?></th>
					<th style="width:40px;"></th>
				</tr>
			</thead>
			<tbody>
			<?php foreach ( $data['items'] as $i => $row ) :
				$rank         = $offset + $i + 1;
				$clicks       = (int) $row->click_count;
				$bar_pct      = $max_clicks > 0 ? round( ( $clicks / $max_clicks ) * 100 ) : 0;
				$dest_url     = $row->destination_url ?: '';
				$edit_url     = admin_url( 'post.php?post=' . (int) $row->ID . '&action=edit' );
				$zero_class   = $clicks === 0 ? ' alc-ta-zero' : '';
			?>
			<tr>
				<td class="alc-rank-cell<?php echo esc_attr( $zero_class ); ?>"><?php echo esc_html( $rank ); ?></td>
				<td>
					<a href="<?php echo esc_url( $edit_url ); ?>" target="_blank" style="text-decoration:none; color:inherit;">
						<?php echo esc_html( $row->post_title ); ?>
					</a>
				</td>
				<td style="max-width:320px; overflow:hidden; text-overflow:ellipsis; white-space:nowrap;">
					<?php if ( $dest_url ) : ?>
					<a href="<?php echo esc_url( $dest_url ); ?>" target="_blank"
					   title="<?php echo esc_attr( $dest_url ); ?>"
					   style="font-size:12px; color:#646970; text-decoration:none;">
						<?php echo esc_html( $dest_url ); ?>
					</a>
					<?php else : ?>
					<span style="color:#b0b0b0; font-size:12px;">—</span>
					<?php endif; ?>
				</td>
				<td class="alc-clicks-cell<?php echo esc_attr( $zero_class ); ?>">
					<?php echo esc_html( number_format_i18n( $clicks ) ); ?>
					<?php if ( $clicks > 0 ) : ?>
					<span class="alc-ta-bar-wrap">
						<span class="alc-ta-bar" style="width:<?php echo esc_attr( $bar_pct ); ?>%;"></span>
					</span>
					<?php endif; ?>
				</td>
				<td style="text-align:center;">
					<a href="<?php echo esc_url( $edit_url ); ?>" target="_blank"
					   title="Bewerk in ThirstyAffiliates" style="text-decoration:none; font-size:15px;">✎</a>
				</td>
			</tr>
			<?php endforeach; ?>
			</tbody>
		</table>

		<?php if ( $total_pages > 1 ) : ?>
		<div class="alc-ta-pagination">
			<?php
			$base_page_url = esc_url( $page_url . '&ta_year=' . $selected_year . '&tapaged=' );
			$this->render_pagination( $current_page, $total_pages, $base_page_url );
			?>
		</div>
		<?php endif; ?>
		<?php endif; ?>
		<?php
	}

	private function render_pagination( int $current, int $total, string $base_url ): void {
		if ( $current > 1 ) {
			echo '<a href="' . esc_url( $base_url . ( $current - 1 ) ) . '">‹ Vorige</a>';
		}

		$window = 2;
		$shown  = [];

		for ( $p = 1; $p <= $total; $p++ ) {
			if ( $p === 1 || $p === $total || abs( $p - $current ) <= $window ) {
				$shown[] = $p;
			}
		}

		$prev = null;
		foreach ( $shown as $p ) {
			if ( $prev !== null && $p - $prev > 1 ) {
				echo '<span class="dots">…</span>';
			}
			if ( $p === $current ) {
				echo '<span class="current-page">' . esc_html( $p ) . '</span>';
			} else {
				echo '<a href="' . esc_url( $base_url . $p ) . '">' . esc_html( $p ) . '</a>';
			}
			$prev = $p;
		}

		if ( $current < $total ) {
			echo '<a href="' . esc_url( $base_url . ( $current + 1 ) ) . '">Volgende ›</a>';
		}
	}
}
