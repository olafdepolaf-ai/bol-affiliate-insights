<?php

namespace TuinenBalkon\AffiliateLinkChecker\Admin;

use TuinenBalkon\AffiliateLinkChecker\Service\LinkScanner;
use TuinenBalkon\AffiliateLinkChecker\Service\OrphanedLinkScanner;
use TuinenBalkon\AffiliateLinkChecker\Service\ScanCacheService;
use TuinenBalkon\AffiliateLinkChecker\Service\ThirstyAffiliatesService;
use TuinenBalkon\AffiliateLinkChecker\Service\TradeTrackerService;

class AjaxHandlerService {

	private LinkScanner              $link_scanner;
	private OrphanedLinkScanner      $orphaned_scanner;
	private ScanCacheService         $scan_cache;
	private ThirstyAffiliatesService $ta_service;
	private TradeTrackerService      $tt_service;

	public function __construct(
		LinkScanner $link_scanner,
		OrphanedLinkScanner $orphaned_scanner,
		ScanCacheService $scan_cache,
		ThirstyAffiliatesService $ta_service,
		TradeTrackerService $tt_service
	) {
		$this->link_scanner     = $link_scanner;
		$this->orphaned_scanner = $orphaned_scanner;
		$this->scan_cache       = $scan_cache;
		$this->ta_service       = $ta_service;
		$this->tt_service       = $tt_service;

		add_action( 'wp_ajax_alc_check_link',            [ $this, 'handle_check_link' ] );
		add_action( 'wp_ajax_alc_orphan_init',           [ $this, 'handle_orphan_init' ] );
		add_action( 'wp_ajax_alc_orphan_batch',          [ $this, 'handle_orphan_batch' ] );
		add_action( 'wp_ajax_alc_orphan_save',           [ $this, 'handle_orphan_save' ] );
		add_action( 'wp_ajax_alc_orphan_find_articles',  [ $this, 'handle_orphan_find_articles' ] );
		add_action( 'wp_ajax_alc_feed_search',           [ $this, 'handle_feed_search' ] );
	}

	/**
	 * Verifieert nonce en beheerdersrechten. Beëindigt het verzoek bij falen.
	 */
	private function authorize( string $nonce_action ): void {
		check_ajax_referer( $nonce_action, 'nonce' );
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_send_json_error( [ 'message' => 'Geen toegang.' ], 403 );
		}
	}

	public function handle_check_link(): void {
		$this->authorize( 'alc_run_scan_nonce' );

		$link_id  = isset( $_POST['link_id'] ) ? (int) $_POST['link_id'] : 0;
		$link_url = isset( $_POST['link_url'] ) ? esc_url_raw( wp_unslash( $_POST['link_url'] ) ) : '';

		if ( ! $link_id || ! $link_url || ! wp_http_validate_url( $link_url ) ) {
			wp_send_json_error( [ 'message' => 'Ongeldige parameters.' ] );
		}

		$result = $this->link_scanner->check_single( $link_id, $link_url );

		wp_send_json_success( $result );
	}

	public function handle_orphan_init(): void {
		$this->authorize( 'alc_orphan_nonce' );

		wp_send_json_success( [
			'total_posts' => $this->orphaned_scanner->get_total_posts(),
		] );
	}

	public function handle_orphan_batch(): void {
		$this->authorize( 'alc_orphan_nonce' );

		$offset = isset( $_POST['offset'] ) ? (int) $_POST['offset'] : 0;
		$limit  = isset( $_POST['limit'] )  ? (int) $_POST['limit']  : 15;
		$limit  = min( max( $limit, 1 ), 50 );

		$active_slugs = $this->ta_service->get_active_slugs();
		$orphans      = $this->orphaned_scanner->scan_batch( $offset, $limit, $active_slugs );

		wp_send_json_success( [ 'orphans' => $orphans ] );
	}

	public function handle_orphan_save(): void {
		$this->authorize( 'alc_orphan_nonce' );

		$raw     = isset( $_POST['results'] ) ? wp_unslash( $_POST['results'] ) : '[]';
		$results = json_decode( $raw, true );

		if ( ! is_array( $results ) ) {
			$results = [];
		}

		$scanned_at = $this->scan_cache->save( 'orphaned_aanbeveling', $results );

		wp_send_json_success( [ 'scanned_at' => $scanned_at ] );
	}

	public function handle_orphan_find_articles(): void {
		$this->authorize( 'alc_orphan_nonce' );

		$slug = isset( $_POST['slug'] ) ? sanitize_title( wp_unslash( $_POST['slug'] ) ) : '';

		if ( empty( $slug ) ) {
			wp_send_json_error( [ 'message' => 'Ongeldige slug.' ] );
		}

		wp_send_json_success( [
			'articles' => $this->orphaned_scanner->find_articles_with_slug( $slug ),
		] );
	}

	public function handle_feed_search(): void {
		$this->authorize( 'alc_tt_feed_nonce' );

		$feed_id  = isset( $_POST['feed_id'] )  ? (int) $_POST['feed_id']                               : 0;
		$search   = isset( $_POST['search'] )   ? sanitize_text_field( wp_unslash( $_POST['search'] ) ) : '';
		$per_page = isset( $_POST['per_page'] ) ? (int) $_POST['per_page']                              : 25;
		$page     = isset( $_POST['page'] )     ? (int) $_POST['page']                                  : 1;

		$per_page = in_array( $per_page, [ 10, 25, 50, 100, 500 ], true ) ? $per_page : 25;
		$page     = max( 1, $page );
		$offset   = ( $page - 1 ) * $per_page;

		if ( ! $feed_id ) {
			wp_send_json_error( [ 'message' => 'Selecteer een productfeed.' ] );
		}

		$site_id = $this->tt_service->get_primary_site_id();
		if ( is_wp_error( $site_id ) ) {
			wp_send_json_error( [ 'message' => $site_id->get_error_message() ] );
		}

		$raw = $this->tt_service->get_feed_products( $site_id, $feed_id, $search, $per_page, $offset );
		if ( is_wp_error( $raw ) ) {
			wp_send_json_error( [ 'message' => $raw->get_error_message() ] );
		}

		$products = [];
		foreach ( $raw as $item ) {
			$p = is_object( $item ) ? $item : (object) $item;

			$image = (string) (
				$p->imageURL ?? $p->imageUrl ?? $p->image_url ?? $p->image ?? $p->imageSmallURL ?? $p->imageSmallUrl ?? ''
			);
			$url = (string) ( $p->URL ?? $p->url ?? $p->productURL ?? '' );
			$price_raw = $p->price ?? $p->Price ?? null;
			$price = $price_raw !== null ? number_format( (float) $price_raw, 2, ',', '.' ) : '';
			$desc  = (string) ( $p->description ?? $p->Description ?? '' );
			if ( strlen( $desc ) > 200 ) {
				$desc = substr( $desc, 0, 197 ) . '...';
			}

			$products[] = [
				'name'     => (string) ( $p->name ?? $p->Name ?? '' ),
				'desc'     => $desc,
				'price'    => $price,
				'image'    => $image,
				'url'      => $url,
				'category' => (string) ( $p->categoryName ?? $p->category ?? '' ),
				'ean'      => (string) ( $p->EAN ?? $p->ean ?? '' ),
			];
		}

		wp_send_json_success( [
			'products'  => $products,
			'page'      => $page,
			'per_page'  => $per_page,
			'has_more'  => count( $products ) === $per_page,
		] );
	}
}
