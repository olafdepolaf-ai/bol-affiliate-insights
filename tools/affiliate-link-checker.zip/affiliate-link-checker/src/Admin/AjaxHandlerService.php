<?php

namespace TuinenBalkon\AffiliateLinkChecker\Admin;

use TuinenBalkon\AffiliateLinkChecker\Service\LinkScanner;
use TuinenBalkon\AffiliateLinkChecker\Service\OrphanedLinkScanner;
use TuinenBalkon\AffiliateLinkChecker\Service\ScanCacheService;
use TuinenBalkon\AffiliateLinkChecker\Service\ThirstyAffiliatesService;

class AjaxHandlerService {

	private LinkScanner            $link_scanner;
	private OrphanedLinkScanner    $orphaned_scanner;
	private ScanCacheService       $scan_cache;
	private ThirstyAffiliatesService $ta_service;

	public function __construct(
		LinkScanner $link_scanner,
		OrphanedLinkScanner $orphaned_scanner,
		ScanCacheService $scan_cache,
		ThirstyAffiliatesService $ta_service
	) {
		$this->link_scanner     = $link_scanner;
		$this->orphaned_scanner = $orphaned_scanner;
		$this->scan_cache       = $scan_cache;
		$this->ta_service       = $ta_service;

		add_action( 'wp_ajax_alc_check_link',            [ $this, 'handle_check_link' ] );
		add_action( 'wp_ajax_alc_orphan_init',           [ $this, 'handle_orphan_init' ] );
		add_action( 'wp_ajax_alc_orphan_batch',          [ $this, 'handle_orphan_batch' ] );
		add_action( 'wp_ajax_alc_orphan_save',           [ $this, 'handle_orphan_save' ] );
		add_action( 'wp_ajax_alc_orphan_find_articles',  [ $this, 'handle_orphan_find_articles' ] );
	}

	public function handle_check_link(): void {
		check_ajax_referer( 'alc_run_scan_nonce', 'nonce' );

		if ( ! current_user_can( 'manage_options' ) ) {
			wp_send_json_error( [ 'message' => 'Geen toegang.' ], 403 );
		}

		$link_id  = isset( $_POST['link_id'] ) ? (int) $_POST['link_id'] : 0;
		$link_url = isset( $_POST['link_url'] ) ? esc_url_raw( wp_unslash( $_POST['link_url'] ) ) : '';

		if ( ! $link_id || ! $link_url ) {
			wp_send_json_error( [ 'message' => 'Ongeldige parameters.' ] );
		}

		$result = $this->link_scanner->check_single( $link_id, $link_url );

		wp_send_json_success( $result );
	}

	public function handle_orphan_init(): void {
		check_ajax_referer( 'alc_orphan_nonce', 'nonce' );

		if ( ! current_user_can( 'manage_options' ) ) {
			wp_send_json_error( [ 'message' => 'Geen toegang.' ], 403 );
		}

		wp_send_json_success( [
			'total_posts' => $this->orphaned_scanner->get_total_posts(),
		] );
	}

	public function handle_orphan_batch(): void {
		check_ajax_referer( 'alc_orphan_nonce', 'nonce' );

		if ( ! current_user_can( 'manage_options' ) ) {
			wp_send_json_error( [ 'message' => 'Geen toegang.' ], 403 );
		}

		$offset = isset( $_POST['offset'] ) ? (int) $_POST['offset'] : 0;
		$limit  = isset( $_POST['limit'] )  ? (int) $_POST['limit']  : 15;
		$limit  = min( max( $limit, 1 ), 50 );

		$active_slugs = $this->ta_service->get_active_slugs();
		$orphans      = $this->orphaned_scanner->scan_batch( $offset, $limit, $active_slugs );

		wp_send_json_success( [ 'orphans' => $orphans ] );
	}

	public function handle_orphan_save(): void {
		check_ajax_referer( 'alc_orphan_nonce', 'nonce' );

		if ( ! current_user_can( 'manage_options' ) ) {
			wp_send_json_error( [ 'message' => 'Geen toegang.' ], 403 );
		}

		$raw     = isset( $_POST['results'] ) ? wp_unslash( $_POST['results'] ) : '[]';
		$results = json_decode( $raw, true );

		if ( ! is_array( $results ) ) {
			$results = [];
		}

		$scanned_at = $this->scan_cache->save( 'orphaned_aanbeveling', $results );

		wp_send_json_success( [ 'scanned_at' => $scanned_at ] );
	}

	public function handle_orphan_find_articles(): void {
		check_ajax_referer( 'alc_orphan_nonce', 'nonce' );

		if ( ! current_user_can( 'manage_options' ) ) {
			wp_send_json_error( [ 'message' => 'Geen toegang.' ], 403 );
		}

		$slug = isset( $_POST['slug'] ) ? sanitize_title( wp_unslash( $_POST['slug'] ) ) : '';

		if ( empty( $slug ) ) {
			wp_send_json_error( [ 'message' => 'Ongeldige slug.' ] );
		}

		wp_send_json_success( [
			'articles' => $this->orphaned_scanner->find_articles_with_slug( $slug ),
		] );
	}
}
