<?php
/**
 * Plugin Name:       Sales Dashboard
 * Plugin URI:        https://example.com/sales-dashboard
 * Description:       A plugin to display sales numbers from an API on an admin page.
 * Version:           0.1.0
 * Author:            Plugin Developer
 * Author URI:        https://example.com/author
 * License:           GPLv2 or later
 * License URI:       https://www.gnu.org/licenses/gpl-2.0.html
 * Text Domain:       sales-dashboard
 * Domain Path:       /languages
 */

// If this file is called directly, abort.
if ( ! defined( 'WPINC' ) ) {
    die;
}

// Plugin code will go here

/**
 * Fetch sales data (placeholder).
 *
 * @return array Sample sales data.
 */
function sales_dashboard_fetch_data() {
    $mock_data = array(
        array('month' => 'January', 'sales' => 1500),
        array('month' => 'February', 'sales' => 1200),
        array('month' => 'March', 'sales' => 1800),
        array('month' => 'April', 'sales' => 1600),
    );
    return $mock_data;
}

/**
 * Register the admin menu page.
 */
function sales_dashboard_admin_menu() {
    add_menu_page(
        'Sales Dashboard',          // Page title
        'Sales Dashboard',          // Menu title
        'manage_options',           // Capability
        'sales-dashboard',          // Menu slug
        'sales_dashboard_page_content', // Callback function
        'dashicons-chart-line',     // Icon URL
        6                           // Position
    );
}
add_action( 'admin_menu', 'sales_dashboard_admin_menu' );

/**
 * Render the content for the admin menu page.
 */
function sales_dashboard_page_content() {
    ?>
    <div class="wrap">
        <h1>Sales Dashboard</h1>
        <?php
        $sales_data = sales_dashboard_fetch_data();

        if ( ! empty( $sales_data ) ) {
            ?>
            <table class="wp-list-table widefat fixed striped">
                <thead>
                    <tr>
                        <th scope="col">Month</th>
                        <th scope="col">Sales</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ( $sales_data as $data_row ) : ?>
                        <tr>
                            <td><?php echo esc_html( $data_row['month'] ); ?></td>
                            <td><?php echo esc_html( $data_row['sales'] ); ?></td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
            <?php
        } else {
            ?>
            <p>No sales data available.</p>
            <?php
        }
        ?>
    </div>
    <?php
}

?>
